# rubeus

## Overview

Kerberoasting tool for windows

## Usage

Kerberoasting

    .\Rubeus.exe kerberoast /user:<domain_username> /nowrap


## More Information

https://github.com/GhostPack/Rubeus