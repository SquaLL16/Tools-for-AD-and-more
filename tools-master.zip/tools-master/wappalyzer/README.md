# Wappalyzer

## Overview

	This plug-in analyzes the web page's code and returns all the different technologies used to build it, such as the webserver type, JavaScript libraries, programming languages, and more. 
