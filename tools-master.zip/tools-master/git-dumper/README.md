# git-dumper

## Overview

A tool to dump a git repository from a website.

## Installation

    pip install git-dumper

## Usage

    git-dumper http://website.com/.git ~/website

## More Information

https://github.com/arthaud/git-dumper
