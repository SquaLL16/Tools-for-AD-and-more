package com.andre.isidoro.testJDBC.connections;

public interface Connection {

	public void connect(String user, String pass);
}
