# hash tools

## hashid

We can use hashid to identify the hash algorithm

## Reference

https://hashcat.net/wiki/doku.php?id=example_hashes

Can helps figure out the hash format