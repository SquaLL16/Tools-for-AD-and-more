# adrecon

## Overview

ADRecon is a tool which extracts and combines various artefacts (as highlighted below) out of an AD environment

## Usage

    .\ADRecon.ps1


## More Information

https://github.com/adrecon/ADRecon