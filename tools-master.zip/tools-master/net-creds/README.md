# net-creds

## Overview

Thoroughly sniff passwords and hashes from an interface or pcap file. Concatenates fragmented packets and does not rely on ports for service identification.


## More Information

    https://github.com/DanMcInerney/net-creds