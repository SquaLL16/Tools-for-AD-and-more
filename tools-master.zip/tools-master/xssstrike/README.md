# xssStrike

## Overview

XSStrike is a Cross Site Scripting detection suite equipped with four hand written parsers, an intelligent payload generator, a powerful fuzzing engine and an incredibly fast crawler.

## Installation

    git clone https://github.com/s0md3v/XSStrike.git