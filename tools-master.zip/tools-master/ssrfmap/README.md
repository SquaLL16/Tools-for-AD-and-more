# ssrfmap

## Overview

First you need a request with a parameter to fuzz, Burp requests works well with SSRFmap.


https://github.com/swisskyrepo/SSRFmap