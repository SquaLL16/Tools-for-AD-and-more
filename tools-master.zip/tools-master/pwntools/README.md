# pwntools

## Overview

pwntools is a python package with a command lin interface, that consists in a CTF framework and exploit development library.



## Command line

    pwn checksec <binary>    Check binary security settings


## More Information

https://github.com/Gallopsled/pwntools
https://docs.pwntools.com/en/latest/