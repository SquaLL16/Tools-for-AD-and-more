# laZagne

## Overview

LaZagne is an open-source tool primarily used for password recovery. It is designed to help security professionals and penetration testers by retrieving passwords stored on a local machine for various applications, services, and platforms. LaZagne works by accessing stored credentials in different places on the system, including web browsers, email clients, chat applications, and databases, among others.

## Usage

Launch all modules

    laZagne.exe all