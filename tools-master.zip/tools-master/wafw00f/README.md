# wafw00f

## Overview

wafw00f is a web application firewall (WAF) fingerprinting tool. Its main purpose is to detect and identify if a website is protected by a WAF, and if so, which WAF is in use.

## Usage

wafw00f http://example.com