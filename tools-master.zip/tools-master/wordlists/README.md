# Wordlists

### SecLists

	https://github.com/danielmiessler/SecLists

## File Inclusion Worldlists

	https://github.com/carlospolop/Auto_Wordlists/blob/main/wordlists/file_inclusion_linux.txt
	https://github.com/carlospolop/Auto_Wordlists/blob/main/wordlists/file_inclusion_windows.txt

## Usernames

	https://github.com/insidetrust/statistically-likely-usernames

## My wordlists

	my_default_usernames.txt
		Some generic usernames usually used as default
	my_default_passwords.txt
		Some generic passwords usually used as default
	my_webserver_files.txt
		Common files sometimes exposed in webservers


## Rules

Good rules to try:

	/usr/share/hashcat/rules/best64.rule