# OWASP-ZAP

## Overview
	OWAS-ZAP : open source tool to primary use of web proxies is to capture and replay HTTP requests

## Installation

	sudo apt install zaproxy
	https://www.kali.org/tools/zaproxy/

## Enabling scripts

	Go to the marketplace and install the following addons:
	Community Scripts
	Python Support
	Kotlin Support
	Ruby Support

	Then on the left side of the zap window open the scripts tab and enable the addons you want to use.
