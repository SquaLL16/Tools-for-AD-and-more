# impacket wmiexec

## Overview

The Impacket wmiexec.py tool typically uses TCP port 135 as it leverages the DCOM (Distributed Component Object Model) service over RPC (Remote Procedure Call) for executing commands on a remote system via WMI (Windows Management Instrumentation).


## Usage

impacket-wmiexec '[username]:[password]@[remote_host_ip]'