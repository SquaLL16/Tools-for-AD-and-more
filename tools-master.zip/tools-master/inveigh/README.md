# inveigh

## Overview

Inveigh is a cross-platform .NET IPv4/IPv6 machine-in-the-middle tool for penetration testers.

Similar to Responder

## Usage

LLMNR NBNS poisoning

    Needs to be run as powershel administrator:
    .\Inveigh.exe

to get the ntlm hashes, press Esc enter the console mode and type "GET NTLMV2UNIQUE"

## More Information

https://github.com/Kevin-Robertson/Inveigh