# swaks

## Overview

	Swiss Army Knife SMTP, the all-purpose SMTP transaction tester

## Usage

Send a mail with an attachement

    swaks -s <mail_server_ip> -f <user.email> -t <receiver.email> --attach @<filename_to_attach>