# feroxbuster

## Overview

Feroxbuster is a tool designed for directory and file busting, which is commonly used in web application security testing.

## Installation

```
sudo apt update && sudo apt install -y feroxbuster
```

## Usage

feroxbuster --url http://bigbang.htb