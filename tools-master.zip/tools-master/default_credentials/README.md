# default credentials

## Overview

One place for all the default credentials to assist pentesters during an engagement, this document has several products default login/password gathered from multiple sources.

https://github.com/ihebski/DefaultCreds-cheat-sheet

## Installtion

pip3 install defaultcreds-cheat-sheet


## Usage

```shell
# Update database
creds update
creds search tomcat
```