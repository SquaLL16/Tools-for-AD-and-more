# Immunity Debugger


## Overview

	Immunity debugger is a debug tool for windows that can debug .exe files

## Useage

Open a .exe by dragging and dropping inside immunity.

To put a breakpoit in the code use F2.

To run the .exe click the play button in the top.

