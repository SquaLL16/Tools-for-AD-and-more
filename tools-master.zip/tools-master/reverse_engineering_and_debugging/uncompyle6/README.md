# uncompyle6 

## Overview

A native Python cross-version decompiler and fragment decompiler. The successor to decompyle, uncompyle, and uncompyle2.

## Installation

pip install uncompyle6

## Usage

uncompyle6 -o . checker.pyc

## Source

https://pypi.org/project/uncompyle6/
