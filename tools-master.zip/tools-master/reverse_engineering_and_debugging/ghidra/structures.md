Structures can be added to Ghidra in multipley ways:
	Import Header files
	Manual creation in structor creator

To import a c file:
	File -> Import C source

Manual struct creation can be done from the data types manager
