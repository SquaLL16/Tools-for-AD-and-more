# ghidra

## How to import an executable

Create a project
Go to File and import he executable and then start the code browser tool, by double clicking the executable.