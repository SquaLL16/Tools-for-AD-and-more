Download ghidra zip file from https://ghidra-sre.org/

unzip it

Install OpenJDK required dependencies apt-get install default-jdk

run ghidra

./ghidraRun

