# powersploit

## Overview

PowerSploit is a collection of Microsoft PowerShell modules that can be used to aid penetration testers during all phases of an assessment.

## PowerView

PowerView is series of functions that performs network and Windows domain enumeration and exploitation.

## Installation

git clone https://github.com/PowerShellMafia/PowerSploit -b dev