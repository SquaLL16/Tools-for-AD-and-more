# exiftool

## Overview

Read and write meta information in files

## Usage

    exiftool <filename>.xlsx