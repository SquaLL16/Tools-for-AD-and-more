# zbarimg

## Overview

Linux utility that for each specified image file zbarimg scans the image for bar codes and prints any decoded data to stdout. Images may optionally be displayed to the screen.

## Installation

    sudo apt install zbar-tools

## Usage

    zbarimg <path_to_imgage_with_qr_code>