# trufflehog

## Overview

trufflehog hunts for credentians in Git, Jira, Slack, Confluence, Microsoft Teams, Sharepoint and more

## Usage

Hunt for credentianls in local repo:

	trufflehog git file:///<absolute_path_to_git_repo>

## More Information

https://github.com/trufflesecurity/trufflehog