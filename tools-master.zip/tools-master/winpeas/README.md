# winPEAS

## Installation

    https://github.com/peass-ng/PEASS-ng/releases

## Usage

    .\winPEASx64.exe


## Other Information

https://github.com/peass-ng/PEASS-ng/tree/master/winPEAS

